// Functionality for the Upload Image button
function handleFileUpload(event) {
    const file = event.target.files[0];
    if (file) {
        console.log('Uploaded file:', file);
        // Add your upload logic here (e.g., upload to server)
    }
}

// Event listener for Login button
document.getElementById('loginBtn').addEventListener('click', function() {
    alert('Login button clicked!'); // Updated message
});

// Event listener for Logout button
document.getElementById('logoutBtn').addEventListener('click', function() {
    alert('Logout button clicked!'); // Updated message
});
